print("collab")
