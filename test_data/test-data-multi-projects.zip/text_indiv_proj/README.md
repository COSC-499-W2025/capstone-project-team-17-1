# Text Indiv Project
A personal documentation project.
